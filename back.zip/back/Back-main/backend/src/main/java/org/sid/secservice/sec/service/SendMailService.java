package org.sid.secservice.sec.service;
import org.sid.secservice.sec.repo.MailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * EmailSenderService
 */
@Service
public class SendMailService {

    @Autowired
    MailRepository repository;
    @Autowired
    JavaMailSender javaMailSender;



    @RequestMapping("/send")
    public void sendMail(String to, String subject, String content) throws MailException
        {
            System.out.println("send email...");
        SimpleMailMessage msg = new SimpleMailMessage();

        msg.setTo(to);
        msg.setFrom("");
        msg.setSubject(subject);
        msg.setText(content);

        this.javaMailSender.send(msg);

        
    }    
}