package org.sid.secservice.sec.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "mail")
public class Mail {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String To;
    private String subject;
    private String content;

    public String toString() {
        return("Mail [id=" + id + "To=" + To + ", subject= " + subject + ", content= " + content + "]");
    }

    public  Mail(long id, String To, String subject, String content) {
        this.id=id;
        this.To=To;
        this.subject=subject;
        this.content=content;
    }

    public  Mail() {
        super();
    }

   public String getContent() {
       return content;
   }
   public void setContent(String content) {
       this.content = content;
   }
   public long getId() {
       return id;
   }
   public void setId(long id) {
       this.id = id;
   }
   public String getSubject() {
       return subject;
   }
   public void setSubject(String subject) {
       this.subject = subject;
   }
   public String getTo() {
       return To;
   }
   public void setTo(String to) {
       To = to;
   }
    
    
}
