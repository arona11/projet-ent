package org.sid.secservice.sec.web;
import org.sid.secservice.sec.entities.Mail;
import org.sid.secservice.sec.service.SendMailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * MailController
 */
@CrossOrigin(origins = "http://localhost:4201")
@RestController

public class MailController {

    @Autowired
    private  SendMailService sendMailService;
    public MailController(SendMailService sendMailService){
        this.sendMailService=sendMailService;
    }

    @PostMapping("/mails")
    public ResponseEntity sendMail (@RequestBody Mail mail){
        this.sendMailService.sendMail(mail.getTo(), mail.getSubject(), mail.getContent());
        return ResponseEntity.ok("succes");
    }
    
}