package org.sid.secservice.sec.repo;

import org.sid.secservice.sec.entities.Mail;
import org.sid.secservice.sec.service.SendMailService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * MailRepository
 */
@Repository
public interface MailRepository extends JpaRepository <SendMailService,Long> {

    
    
}